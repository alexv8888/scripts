#!/bin/bash
path=$(dirname $1)
#A function to parse the first line of the output.txt
function firstline() {
testname=$(echo $line | awk '{for (i = 2; i <= NF-3; i ++) printf $i" "}'| sed 's/.$//')
echo '{' > $path/temp.json
echo ' '\"testname\": \""$testname"\", >> $path/temp.json
echo ' '\"tests\": \[ >> $path/temp.json
}

#Functions to parse 'tests' lins of the output.txt
function midline1() {
status='true'
name=$(echo $line | awk '{for (i = 3; i <= NF-1; i ++) printf $i" "}'| sed 's/..$//')
duration=$(echo $line | awk '{print $NF}')
echo '  {' >> $path/temp.json
echo '   '\"name\": \""$name"\", >> $path/temp.json
echo '   '\"status\": "$status", >> $path/temp.json
echo '   '\"duration\": \""$duration"\" >> $path/temp.json
echo '  },' >> $path/temp.json
}

function midline2() {
status='false'
name=$(echo $line | awk '{for (i = 4; i <= NF-1; i ++) printf $i" "}'| sed 's/..$//')
duration=$(echo $line | awk '{print $NF}')
echo '  {' >> $path/temp.json
echo '   '\"name\": \""$name"\", >> $path/temp.json
echo '   '\"status\": "$status", >> $path/temp.json
echo '   '\"duration\": \""$duration"\" >> $path/temp.json
echo '  },' >> $path/temp.json
}
#A function to parse the last line of the output.txt
function lastline() {
success=$(echo $line | awk '{print $1}')
failed=$(echo $line | awk '{print $6}')
rating=$(echo $line | awk '{print $(NF-2)}' | sed 's/..$//')
duration=$(echo $line | awk '{print $NF}')
echo ' ],' >> $path/temp.json
echo ' '\"summary\": { >> $path/temp.json
echo '  '\"success\": "$success", >> $path/temp.json
echo '  '\"failed\": "$failed", >> $path/temp.json
echo '  '\"rating\": "$rating", >> $path/temp.json
echo '  '\"duration\": \""$duration"\" >> $path/temp.json
echo ' }' >> $path/temp.json
echo '}' >> $path/temp.json

}

while read  line; do
 if [[ $line =~ ^\[.*$ ]];
 then firstline
 elif [[ $line =~ ^n.*$ ]];
 then midline2
 elif [[ $line =~ ^o.*$ ]];
 then midline1
 elif [[ $line =~ ^[0-9].*$ ]];
 then lastline
 fi
done < $1

#Remove an extra comma from the json file
cat $path/temp.json | tr '\n' '#' | sed 's/},# ]/}# ]/' | tr '#' '\n' > $path/output.json
rm $path/temp.json
