#!/bin/bash

path=$(dirname $1)

arr_id=()
arr_lid=()
arr_name=()
arr_title=()
arr_email=()
arr_dept=()

r=0

head -n1 $1 > $path/accounts_new.csv

#Replace comma in fields with quotas (e.g. "Director, Second Career Services" to "Director# Second Career Services")

while read  line; do
echo $line | sed 's/\(\"\)\(.*\)\(,\)\(.*\)\(\"\)/\1\2#\4\5/' >> $path/accounts_temp.csv
done < $1

#Modify names and emails
while IFS="," read -r id lid name title email dept;
do
NAME_NORM=$(echo "$name" | sed -e "s/\b\(.\)/\u\1/g")
EMAIL=${name:0:1}`echo $name | awk '{print $2}'` 
EMAIL_LC=`echo $EMAIL | tr "[:upper:]" "[:lower:]"`

arr_id[r]="$id"
arr_lid[r]="$lid"
arr_name[r]="$NAME_NORM"
arr_title[r]="$title"
arr_email[r]="$EMAIL_LC"
arr_dept[r]="$dept"
(( r++ ))

done < <(tail -n +2 $path/accounts_temp.csv)

#Find equal emails
len=${#arr_email[@]}

for (( var=0; var<${len}; var++ ))
do

V=`printf '%s\n' "${arr_email[@]}" | grep  -c "${arr_email[$var]}"` 

if [[ "$V" -ne  1 ]]
then
arr_EMAIL_NORM[var]="${arr_email[$var]}""${arr_lid[$var]}"@abc.com
else
arr_EMAIL_NORM[var]="${arr_email[$var]}"@abc.com
fi

echo "${arr_id[$var]}","${arr_lid[$var]}","${arr_name[$var]}","${arr_title[$var]}","${arr_EMAIL_NORM[$var]}","${arr_dept[$var]}">>$path/accounts_temp2.csv
done

#Replace # back to the comma
while read  line; do
echo $line | sed 's/#/,/' >> $path/accounts_new.csv
done < $path/accounts_temp2.csv

rm $path/accounts_temp.csv $path/accounts_temp2.csv