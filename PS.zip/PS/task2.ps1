
$file=Import-Csv $args[0]
$output=[String](Get-ChildItem $args[0]).Directory+'\accounts_new.csv'

"id,location_id,name,title,email,department" > .\accounts_new.csv
$email_list=''
    $file | ForEach-Object { 
        $email = ($_.name[0] + $_.name.Split(" ")[1] + '@abc.com').ToLower()
        $email_list=$email_list, $email -join(",") 
     }
     $i=0
     foreach ($item in $email_list.Remove(0,1).Split(',')) {
         
        $newname = (Get-Culture).TextInfo.ToTitleCase($file[$i].name)
        [regex]$regex = "$item"
        $equalemailcount=$regex.matches($email_list).count
        if ( $equalemailcount -gt 1 )
     {
        $finalemail= ($file[$i].name[0] +  $file[$i].name.Split(" ")[1] + $file[$i].location_id + '@abc.com').ToLower()
        $user = $file[$i].id + ',' + $file[$i].location_id +',' + $newname + ',"' + $file[$i].title + '",' + $finalemail + ',' + $file[$i].department
        $user >> $output
    }
    else {
        $user = $file[$i].id + ',' + $file[$i].location_id +',' + $newname + ',"' + $file[$i].title + '",' + $item + ',' + $file[$i].department
        $user >> $output
        }  
        $i++
    }