Param (
[Parameter (Mandatory=$true, Position=1)]
[string]$ip_address_1,

[Parameter (Mandatory=$true, Position=2)]
[string]$ip_address_2,

[Parameter (Mandatory=$true, Position=3)]
[string]$network_mask
)

#pattern for IPv4 address
$pattern = "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"



#check if ip1 is valid
if ("$ip_address_1" -notmatch $pattern) {
write-host "$ip_address_1 is not a valid IP address"
break
}

#check if ip2 is valid
if ("$ip_address_2" -notmatch $pattern) {
    write-host "$ip_address_2 is not a valid IP address"
    break
    }

#check if mask is valid
if ($network_mask -in 1..32) {
    $one=[int32]$network_mask
    $zero=32-[int32]$network_mask
    $bin='1'*$one+'0'*$zero
    $network_mask=([System.Net.IPAddress]"$([System.Convert]::ToInt64($bin,2))").IPAddressToString
}
elseif ("$network_mask" -match $pattern ) {

    $maskpattern = -join ($network_mask.split(".") | foreach-object {[system.convert]::tostring($_, 2).padleft(8, "0")}) 
    if ($maskpattern.Contains('01')) {
        write-host "$network_mask is not a valid mask"
        break
    }
}
else {
    write-host "$network_mask is not a valid mask"
    break
}

$IsEqualSubnet = (([Net.IPAddress]$ip_address_1).address -band ([Net.IPAddress]$network_mask).address) -eq (([Net.IPAddress]$ip_address_2).address -band ([Net.IPAddress]$network_mask).address)
if ($IsEqualSubnet) {
    write-host 'yes'
}
else { 
    write-host 'no'
}